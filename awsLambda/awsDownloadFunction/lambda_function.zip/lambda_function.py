import json

def lambda_handler(event, context):
    from awsLambda.awsDownloadFunction.utils import downloadB3
    
    downloadB3()
    
    return {
        'statusCode': 200,
        'body': 'Files downloaded and uploaded to S3 successfully!'
    }